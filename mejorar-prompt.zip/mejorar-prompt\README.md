# mejorar-prompt

Antes de que Claude lea tu mensaje (de 25 caracteres o más), Haiku lo reescribe en primera persona con estas secciones: Objetivo, Contexto, Requisitos, Restricciones y Dudas. Para entender referencias como "eso" o "lo de antes", Haiku ve también los últimos 6 mensajes de la conversación.

## Instalación (solo este PC)

Desde un terminal, con la carpeta del mod en `C:\Users\aleja\Proyectos\mejorar-prompt`:

```bash
claude plugin marketplace add C:\Users\aleja\Proyectos\mejorar-prompt
claude plugin install mejorar-prompt@mejorar-prompt-local
```

En la app de escritorio: pulsa + junto al cuadro de texto, luego Plugins, Add marketplace con la ruta de arriba, y después Add plugin. Se carga en las sesiones nuevas.

Para quitarlo: `claude plugin uninstall mejorar-prompt@mejorar-prompt-local`.

## Modos

| Comando | Qué pasa al pulsar Enter |
| --- | --- |
| `/mejorar revisar` (por defecto) | Tu mensaje **no se envía**: vuelve mejorado a la caja de texto. Lo revisas o lo editas y pulsas Enter otra vez. Solo entonces se procesa, una única vez. |
| `/mejorar sustituir` | Se envía directamente la versión mejorada y es la que ves en la conversación. Tu original se le pasa a Claude de forma oculta, por si acaso. |
| `/mejorar off` | No toca nada. |
| `/mejorar on` | Vuelve al último modo activo. |
| `/mejorar` | Muestra el modo actual. |

Mientras está activo, la barra de estado muestra el modo. Con cualquier modo activo, cada mensaje lleva una instrucción para que Claude te pregunte lo que no esté claro en lugar de suponer.

Si Haiku falla o tarda más de 8 s, se envía tu mensaje original.
