import { expect, test } from 'claude-code/testing'

const SUBMIT = {
  text: 'quiero que la lista de la compra se ordene por pasillos del super',
  wait: false,
  origin: { kind: 'composer' },
} as const

const IMPROVED = 'OBJETIVO: quiero ordenar la lista por pasillos\nDUDAS:\n- ¿Qué supermercado?'

// Simula el engine con el modo dado y Haiku respondiendo `reply`.
const engine = (on: any, mode: string | undefined, reply: any) => {
  const seen = { submitted: [] as { text: string; context: readonly string[] }[], filled: [] as string[], prompts: [] as string[] }
  on('store.get', (_: any, e: any) => ({ value: e.key === 'mode' ? mode : undefined }))
  on('store.set', () => ({ value: undefined }))
  on('ui.status', () => ({ value: undefined }))
  on('ui.toast', () => ({ value: undefined }))
  on('clock.after', (_: any, e: any) => ({ value: undefined }))
  on('model.complete', (_: any, e: any) => {
    seen.prompts.push(e.prompt)
    return { value: reply }
  })
  on('prompt.fill', (_: any, e: any) => {
    seen.filled.push(e.text)
    return { isFilled: true }
  })
  on('prompt.submit', (_: any, e: any) => {
    seen.submitted.push({ text: e.text, context: e.context ?? [] })
    return { text: e.text }
  })
  on('turn.complete', (_: any, e: any) => ({ text: e.answer }))
  return seen
}

const OK = { isAnswered: true, text: IMPROVED, usage: { input_tokens: 1, output_tokens: 1 } }

test('sustituir: se envía la versión mejorada, con el original oculto y la regla', async ($, on) => {
  const seen = engine(on, 'sustituir', OK)

  await $.prompt.submit(SUBMIT)

  expect(seen.submitted.length).toBe(1)
  expect(seen.submitted[0].text).toBe(IMPROVED)
  expect(seen.submitted[0].context[0]).toContain('PREGÚNTALE')
  expect(seen.submitted[0].context[1]).toContain('ordene por pasillos')
})

test('revisar: el primer Enter no se procesa; el segundo pasa tal cual una sola vez', async ($, on) => {
  const seen = engine(on, 'revisar', OK)

  const first = await $.prompt.submit(SUBMIT)
  expect('drop' in first && first.drop).toBeTruthy()
  expect(seen.submitted.length).toBe(0)

  await $.prompt.submit({ ...SUBMIT, text: IMPROVED + '\n(editado)' })
  expect(seen.submitted.length).toBe(1)
  expect(seen.submitted[0].text).toBe(IMPROVED + '\n(editado)')
  expect(seen.prompts.length).toBe(1) // Haiku solo una vez
})

test('si Haiku falla, el mensaje original pasa con la regla', async ($, on) => {
  const seen = engine(on, 'sustituir', { isAnswered: false, reason: 'aborted' })

  await $.prompt.submit(SUBMIT)

  expect(seen.submitted[0].text).toBe(SUBMIT.text)
  expect(seen.submitted[0].context.length).toBe(1)
})

test('Haiku recibe la conversación previa', async ($, on) => {
  const seen = engine(on, 'sustituir', OK)

  await $.prompt.submit(SUBMIT)
  await $.turn.complete({ answer: 'He creado el plugin de pasillos.', durationMs: 1, isAborted: false, turnId: 't1', reason: 'answer' })
  await $.prompt.submit({ ...SUBMIT, text: 'comprueba que eso funciona bien, por favor' })

  expect(seen.prompts[0]).not.toContain('Conversación previa')
  expect(seen.prompts[1]).toContain('He creado el plugin de pasillos.')
})

test('off: no toca nada', async ($, on) => {
  const seen = engine(on, 'off', OK)

  await $.prompt.submit(SUBMIT)

  expect(seen.submitted[0].text).toBe(SUBMIT.text)
  expect(seen.submitted[0].context.length).toBe(0)
  expect(seen.prompts.length).toBe(0)
})
