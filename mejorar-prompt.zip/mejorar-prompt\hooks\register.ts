import type { EngineInterface, Register } from 'claude-code'

// Modos:
//  revisar   → Enter no envía: tu mensaje vuelve mejorado a la caja; lo revisas y Enter otra vez lo envía.
//  sustituir → Enter envía directamente la versión mejorada (es la que ves en la conversación).
//  off       → no toca nada.
type Mode = 'revisar' | 'sustituir' | 'off'
const MODE_KEY = 'mode' // $.store: persiste entre sesiones
const LAST_ON_KEY = 'lastOn' // último modo activo, para /mejorar on
const DEFAULT_MODE: Mode = 'revisar'
// Mensajes más cortos que esto ("sí", "ok, hazlo") pasan tal cual.
const MIN_CHARS = 25

const SYSTEM = `Eres un asistente que reescribe peticiones de un usuario para que otro modelo de IA (Claude) las entienda sin ambigüedad.
NO respondas a la petición. NO inventes requisitos, datos ni detalles que el usuario no haya dicho.
Devuelve SOLO este formato, en el mismo idioma del usuario, omitiendo secciones vacías:

OBJETIVO: una frase con lo que el usuario quiere conseguir.
CONTEXTO: lo que el usuario da por sabido (proyecto, archivos, situación) según su mensaje.
REQUISITOS:
- cada cosa concreta que pide
RESTRICCIONES:
- lo que NO quiere, límites, preferencias
DUDAS:
- cada punto ambiguo, incompleto o con varias interpretaciones, formulado como pregunta para el usuario

Escribe en primera persona, como si fuera el propio usuario quien lo escribe ("quiero…", "no quiero…").
Si se te da la conversación previa, úsala para entender referencias ("eso", "lo de antes", "hazlo") y rellenar CONTEXTO, y NO pongas en DUDAS nada que ya se responda en ella.
Sé breve y fiel al mensaje original.`

const RULE = `Instrucción del usuario (plugin mejorar-prompt): si algo de su petición no está claro o admite varias interpretaciones que cambien el resultado, PREGÚNTALE antes de actuar en lugar de suponer. No asumas a lo loco. Si las dudas son menores, di qué supones y sigue.`

// Últimos intercambios de la conversación principal, para que Haiku entienda referencias.
const MAX_TURNS = 6 // mensajes (usuario + Claude), ~3 intercambios
const MAX_CHARS_PER_MSG = 1500
type Msg = { who: 'Usuario' | 'Claude'; text: string }

const clip = (t: string) =>
  t.length > MAX_CHARS_PER_MSG ? `${t.slice(0, MAX_CHARS_PER_MSG)}…` : t

const STATUS: Record<Mode, string | undefined> = {
  revisar: '✨ mejorar: revisar',
  sustituir: '✨ mejorar: sustituir',
  off: undefined,
}

async function getMode($: EngineInterface): Promise<Mode> {
  const v = await $.store.get(MODE_KEY).catch(() => undefined)
  return v === 'revisar' || v === 'sustituir' || v === 'off' ? v : DEFAULT_MODE
}

export const register: Register = on => {
  let history: Msg[] = []
  // En modo revisar: true tras devolverte el mensaje mejorado a la caja;
  // el siguiente envío es el que ya revisaste y pasa sin tocar.
  let awaitingReview = false

  const remember = (m: Msg) => {
    if (m.text.trim()) history = [...history, { ...m, text: clip(m.text.trim()) }].slice(-MAX_TURNS)
  }

  on('turn.complete', async ($, e, next) => {
    if (e.agentId === undefined && !e.isAborted) remember({ who: 'Claude', text: e.answer })
    return next(e)
  })

  on('session.start', async ($, e, next) => {
    await $.command.register({
      name: 'mejorar',
      description: 'Mejora de mensajes: /mejorar revisar | sustituir | off | on (sin nada: ver el modo)',
    })
    $.ui.status(STATUS[await getMode($)])

    return next(e)
  })

  on('command.run', { command: 'mejorar' }, async ($, e) => {
    const arg = (e.args ?? '').trim().toLowerCase()
    let mode = await getMode($)

    if (arg === 'revisar' || arg === 'sustituir' || arg === 'off') {
      mode = arg
    } else if (arg === 'on') {
      const last = await $.store.get(LAST_ON_KEY).catch(() => undefined)
      mode = last === 'sustituir' ? 'sustituir' : 'revisar'
    } else if (arg !== '') {
      return { text: 'Uso: /mejorar revisar | sustituir | off | on' }
    }

    await $.store.set(MODE_KEY, mode)
    if (mode !== 'off') await $.store.set(LAST_ON_KEY, mode)
    awaitingReview = false
    $.ui.status(STATUS[mode])

    const help: Record<Mode, string> = {
      revisar: 'Modo revisar: al pulsar Enter tu mensaje vuelve mejorado a la caja; revísalo y pulsa Enter otra vez para enviarlo.',
      sustituir: 'Modo sustituir: al pulsar Enter se envía directamente la versión mejorada.',
      off: 'mejorar-prompt desactivado.',
    }
    return { text: help[mode] }
  })

  on('prompt.submit', async ($, e, next) => {
    // Terminal, Remote Control (móvil/web) y la app de escritorio (llega como 'sdk').
    const isUser = ['composer', 'bridge', 'sdk'].includes(e.origin.kind)
    if (e.command || e.isMeta || !isUser) return next(e)

    const mode = await getMode($)
    if (mode === 'off') return next(e)

    const context = [...(e.context ?? []), RULE]
    const previous = history.map(m => `${m.who}: ${m.text}`).join('\n\n')

    // El mensaje que ya revisaste: se envía tal cual, una sola vez.
    if (awaitingReview) {
      awaitingReview = false
      remember({ who: 'Usuario', text: e.text })
      return next({ ...e, context })
    }

    if (e.text.trim().length < MIN_CHARS) {
      remember({ who: 'Usuario', text: e.text })
      return next({ ...e, context })
    }

    $.ui.status('✨ mejorando…')
    // Si Haiku falla o tarda, el mensaje pasa igual: nunca bloquea tu prompt.
    const r = await $.model
      .complete({
        model: 'haiku',
        system: SYSTEM,
        prompt:
          (previous ? `Conversación previa (solo como contexto):\n"""\n${previous}\n"""\n\n` : '') +
          `Mensaje del usuario a reescribir:\n"""\n${e.text}\n"""`,
        effort: 'low',
        maxTokens: 800,
        timeoutMs: 8000,
      })
      .catch(() => null)
    $.ui.status(STATUS[mode])

    const improved = r?.isAnswered ? r.text.trim() : ''
    if (!improved) {
      $.ui.toast('mejorar-prompt: no se pudo mejorar, se envía tu mensaje original')
      remember({ who: 'Usuario', text: e.text })
      return next({ ...e, context })
    }

    if (mode === 'revisar') {
      // No se procesa: lo devolvemos mejorado a la caja, justo después de que el engine la vacíe.
      awaitingReview = true
      $.clock.after(150, () => {
        void $.prompt
          .fill({ text: improved })
          .then(f => {
            if (!f.isFilled) {
              awaitingReview = false
              $.ui.toast('mejorar-prompt: no pude rellenar la caja; usa /mejorar sustituir')
            } else {
              $.ui.toast('Revisa el mensaje mejorado y pulsa Enter para enviarlo')
            }
          })
          .catch(() => {
            awaitingReview = false
          })
      })
      return { drop: 'mejorar-prompt: mensaje devuelto mejorado a la caja para que lo revises' }
    }

    // sustituir: se envía la versión mejorada (la que ves); el original va oculto por si acaso.
    remember({ who: 'Usuario', text: improved })
    return next({
      ...e,
      text: improved,
      context: [...context, `Mensaje original del usuario, antes de mejorarlo (si contradice la versión mejorada, manda este):\n\n${e.text}`],
    })
  })
}
